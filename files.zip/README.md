# F1 Simulator Game 🏎️

A browser-based Formula 1 racing simulation game built with React. Race for 10 laps, manage your tires and fuel, use DRS strategically, and set the best lap time!

## Features

- **Realistic Racing Mechanics**: Speed, acceleration, and braking physics
- **DRS System**: Activate DRS in designated zones for extra speed
- **Tire Management**: Tire wear affects performance over time
- **Fuel Consumption**: Monitor your fuel levels throughout the race
- **Dynamic Weather**: Race in sunny, cloudy, or rainy conditions
- **Lap Timing**: Track your lap times and beat your personal best
- **Visual Track**: See your position on the track with DRS zones highlighted

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/f1-sim-game.git
cd f1-sim-game
```

2. Install dependencies
```bash
npm install
# or
yarn install
```

3. Start the development server
```bash
npm start
# or
yarn start
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## How to Play

### Controls

- **↑ Accelerate**: Hold to increase speed
- **↓ Brake**: Hold to decrease speed  
- **DRS Button**: Activate DRS when available (blue zones, speed > 200 km/h)

### Game Mechanics

1. **Starting the Race**: Click "Start Race" to begin a 10-lap race
2. **Acceleration**: Build up speed by holding the accelerate button
3. **DRS Zones**: Blue zones on the track indicate where DRS can be activated for a speed boost
4. **Tire Wear**: Your tires degrade over time, affecting performance
5. **Fuel Management**: Keep an eye on fuel levels - running out slows you down
6. **Weather**: Random weather conditions affect maximum speed and handling
7. **Lap Times**: Complete all 10 laps and try to set the fastest lap time!

### Tips

- Use DRS strategically in the designated zones for maximum speed
- Manage tire wear by not constantly pushing to maximum speed
- Watch your fuel - plan your acceleration carefully
- Rainy weather reduces maximum speed, so adjust your strategy

## Technology Stack

- **React**: Frontend framework
- **Tailwind CSS**: Styling
- **Lucide React**: Icons
- **JavaScript**: Game logic and mechanics

## Project Structure

```
f1-sim-game/
├── src/
│   ├── App.jsx              # Main game component
│   └── index.js             # Entry point
├── public/
│   └── index.html
├── package.json
└── README.md
```

## Game States

- **Menu**: Start screen with game introduction
- **Racing**: Active gameplay with all mechanics
- **Finished**: Results screen showing all lap times and best lap

## Future Enhancements

Potential features for future versions:

- Multiple tracks with different characteristics
- Pit stop strategy and tire changes
- Multiplayer racing
- More weather conditions and effects
- Car upgrades and customization
- Championship mode with multiple races
- Leaderboard system
- Sound effects and music

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the project
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Inspired by Formula 1 racing
- Built with React and modern web technologies
- Icons by Lucide

## Contact

Your Name - [@yourtwitter](https://twitter.com/yourtwitter)

Project Link: [https://github.com/yourusername/f1-sim-game](https://github.com/yourusername/f1-sim-game)

---

Made with ❤️ for F1 fans
