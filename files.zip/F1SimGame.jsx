import React, { useState, useEffect, useRef } from 'react';
import { Flag, Zap, Gauge, CloudRain, Sun, Wind } from 'lucide-react';

export default function F1SimGame() {
  const [gameState, setGameState] = useState('menu'); // menu, racing, finished
  const [speed, setSpeed] = useState(0);
  const [position, setPosition] = useState(0);
  const [lap, setLap] = useState(1);
  const [lapTime, setLapTime] = useState(0);
  const [bestLap, setBestLap] = useState(null);
  const [lapTimes, setLapTimes] = useState([]);
  const [fuel, setFuel] = useState(100);
  const [tireWear, setTireWear] = useState(0);
  const [drsAvailable, setDrsAvailable] = useState(false);
  const [drsActive, setDrsActive] = useState(false);
  const [weather, setWeather] = useState('sunny');
  const [totalLaps] = useState(10);
  
  const animationRef = useRef();
  const lapStartTime = useRef(Date.now());

  const maxSpeed = weather === 'rainy' ? 280 : 320;
  const trackLength = 5000;

  useEffect(() => {
    if (gameState === 'racing') {
      const gameLoop = () => {
        setLapTime((Date.now() - lapStartTime.current) / 1000);
        
        // Update position based on speed
        setPosition(prev => {
          const newPos = prev + (speed / 100);
          
          // Check if lap completed
          if (newPos >= trackLength) {
            const completedLapTime = (Date.now() - lapStartTime.current) / 1000;
            setLapTimes(prev => [...prev, completedLapTime]);
            
            if (!bestLap || completedLapTime < bestLap) {
              setBestLap(completedLapTime);
            }
            
            if (lap >= totalLaps) {
              setGameState('finished');
              return trackLength;
            }
            
            setLap(prev => prev + 1);
            lapStartTime.current = Date.now();
            return 0;
          }
          
          return newPos;
        });

        // Tire wear increases with speed and cornering
        setTireWear(prev => Math.min(100, prev + (speed / 50000)));
        
        // Fuel consumption
        setFuel(prev => Math.max(0, prev - (speed / 100000)));
        
        // DRS availability (available in certain zones)
        const trackProgress = (position / trackLength) * 100;
        setDrsAvailable(trackProgress > 20 && trackProgress < 40 || trackProgress > 70 && trackProgress < 90);
        
        animationRef.current = requestAnimationFrame(gameLoop);
      };
      
      animationRef.current = requestAnimationFrame(gameLoop);
      
      return () => {
        if (animationRef.current) {
          cancelAnimationFrame(animationRef.current);
        }
      };
    }
  }, [gameState, speed, position, lap, bestLap, totalLaps]);

  const handleAccelerate = () => {
    const weatherPenalty = weather === 'rainy' ? 0.7 : 1;
    const tirePenalty = 1 - (tireWear / 200);
    const drsBonus = drsActive ? 1.15 : 1;
    
    setSpeed(prev => Math.min(maxSpeed, prev + (5 * weatherPenalty * tirePenalty * drsBonus)));
  };

  const handleBrake = () => {
    setSpeed(prev => Math.max(0, prev - 10));
  };

  const toggleDrs = () => {
    if (drsAvailable && speed > 200) {
      setDrsActive(prev => !prev);
    }
  };

  const startRace = () => {
    setGameState('racing');
    setSpeed(0);
    setPosition(0);
    setLap(1);
    setLapTime(0);
    setLapTimes([]);
    setBestLap(null);
    setFuel(100);
    setTireWear(0);
    setDrsActive(false);
    lapStartTime.current = Date.now();
    
    // Random weather
    const conditions = ['sunny', 'cloudy', 'rainy'];
    setWeather(conditions[Math.floor(Math.random() * conditions.length)]);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = (seconds % 60).toFixed(3);
    return `${mins}:${secs.padStart(6, '0')}`;
  };

  if (gameState === 'menu') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-600 to-gray-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-2xl p-8 max-w-md w-full text-center">
          <Flag className="w-20 h-20 mx-auto mb-4 text-red-600" />
          <h1 className="text-4xl font-bold mb-2 text-gray-800">F1 Simulator</h1>
          <p className="text-gray-600 mb-8">Race for {totalLaps} laps and set the best time!</p>
          <button
            onClick={startRace}
            className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-8 rounded-lg text-xl transition-colors"
          >
            Start Race
          </button>
          <div className="mt-6 text-sm text-gray-500">
            <p>Controls:</p>
            <p>↑ Accelerate | ↓ Brake | Space: DRS</p>
          </div>
        </div>
      </div>
    );
  }

  if (gameState === 'finished') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-600 to-gray-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-2xl p-8 max-w-2xl w-full">
          <Flag className="w-20 h-20 mx-auto mb-4 text-green-600" />
          <h1 className="text-4xl font-bold mb-6 text-center text-gray-800">Race Complete!</h1>
          
          <div className="mb-6 p-4 bg-yellow-100 rounded-lg">
            <p className="text-xl font-bold text-center">Best Lap: {formatTime(bestLap)}</p>
          </div>
          
          <div className="mb-6">
            <h2 className="text-2xl font-bold mb-3">Lap Times</h2>
            <div className="space-y-2">
              {lapTimes.map((time, idx) => (
                <div key={idx} className="flex justify-between p-2 bg-gray-100 rounded">
                  <span className="font-semibold">Lap {idx + 1}</span>
                  <span className={time === bestLap ? 'text-green-600 font-bold' : ''}>
                    {formatTime(time)}
                  </span>
                </div>
              ))}
            </div>
          </div>
          
          <button
            onClick={() => setGameState('menu')}
            className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-lg transition-colors"
          >
            Back to Menu
          </button>
        </div>
      </div>
    );
  }

  const WeatherIcon = weather === 'rainy' ? CloudRain : weather === 'cloudy' ? Wind : Sun;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-800 to-gray-900 text-white p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-gray-800 rounded-lg p-4 mb-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <WeatherIcon className="w-8 h-8" />
            <span className="text-xl capitalize">{weather}</span>
          </div>
          <div className="text-2xl font-bold">
            Lap {lap}/{totalLaps}
          </div>
          <div className="text-xl">
            {formatTime(lapTime)}
          </div>
        </div>

        {/* Main Display */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          {/* Speed */}
          <div className="bg-gray-800 rounded-lg p-6 text-center">
            <Gauge className="w-12 h-12 mx-auto mb-2 text-red-500" />
            <div className="text-5xl font-bold mb-2">{Math.round(speed)}</div>
            <div className="text-gray-400">km/h</div>
            <div className="mt-4 bg-gray-700 rounded-full h-4">
              <div 
                className="bg-red-500 h-4 rounded-full transition-all"
                style={{ width: `${(speed / maxSpeed) * 100}%` }}
              />
            </div>
          </div>

          {/* Tire Wear */}
          <div className="bg-gray-800 rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-3">Tire Wear</h3>
            <div className="bg-gray-700 rounded-full h-6 mb-2">
              <div 
                className={`h-6 rounded-full transition-all ${
                  tireWear > 70 ? 'bg-red-500' : tireWear > 40 ? 'bg-yellow-500' : 'bg-green-500'
                }`}
                style={{ width: `${tireWear}%` }}
              />
            </div>
            <div className="text-2xl font-bold text-center">{Math.round(tireWear)}%</div>
          </div>

          {/* Fuel */}
          <div className="bg-gray-800 rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-3">Fuel</h3>
            <div className="bg-gray-700 rounded-full h-6 mb-2">
              <div 
                className={`h-6 rounded-full transition-all ${
                  fuel < 20 ? 'bg-red-500' : fuel < 50 ? 'bg-yellow-500' : 'bg-green-500'
                }`}
                style={{ width: `${fuel}%` }}
              />
            </div>
            <div className="text-2xl font-bold text-center">{Math.round(fuel)}%</div>
          </div>
        </div>

        {/* Track */}
        <div className="bg-gray-800 rounded-lg p-6 mb-4">
          <div className="flex justify-between mb-2 text-sm text-gray-400">
            <span>Start</span>
            <span>Finish</span>
          </div>
          <div className="bg-gray-700 rounded-full h-12 relative overflow-hidden">
            {/* DRS Zones */}
            <div className="absolute bg-blue-500 opacity-20 h-12" style={{ left: '20%', width: '20%' }} />
            <div className="absolute bg-blue-500 opacity-20 h-12" style={{ left: '70%', width: '20%' }} />
            
            {/* Car position */}
            <div 
              className="absolute top-1 bg-red-600 h-10 w-10 rounded-full flex items-center justify-center transition-all"
              style={{ left: `calc(${(position / trackLength) * 100}% - 20px)` }}
            >
              🏎️
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          <button
            onMouseDown={handleAccelerate}
            className="bg-green-600 hover:bg-green-700 text-white font-bold py-6 rounded-lg text-xl transition-colors"
          >
            ↑ Accelerate
          </button>
          <button
            onClick={toggleDrs}
            disabled={!drsAvailable || speed <= 200}
            className={`font-bold py-6 rounded-lg text-xl transition-colors flex items-center justify-center gap-2 ${
              drsActive ? 'bg-blue-600 hover:bg-blue-700' : 
              drsAvailable && speed > 200 ? 'bg-blue-500 hover:bg-blue-600' : 'bg-gray-600'
            } text-white`}
          >
            <Zap className="w-6 h-6" />
            DRS {drsActive ? 'ON' : 'OFF'}
          </button>
          <button
            onMouseDown={handleBrake}
            className="bg-red-600 hover:bg-red-700 text-white font-bold py-6 rounded-lg text-xl transition-colors"
          >
            ↓ Brake
          </button>
        </div>

        {/* Stats */}
        <div className="bg-gray-800 rounded-lg p-4">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <div className="text-gray-400 text-sm">Best Lap</div>
              <div className="text-xl font-bold">{bestLap ? formatTime(bestLap) : '--:--:---'}</div>
            </div>
            <div>
              <div className="text-gray-400 text-sm">Last Lap</div>
              <div className="text-xl font-bold">
                {lapTimes.length > 0 ? formatTime(lapTimes[lapTimes.length - 1]) : '--:--:---'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}